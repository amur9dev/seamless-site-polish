# 🏢 Стеклопром — Производство стеклопакетов в Ростове-на-Дону

Корпоративный сайт компании «Стеклопром» — производителя стеклопакетов в Ростове-на-Дону с 2008 года.

## 📋 Содержание

- [Технологии](#-технологии)
- [Структура проекта](#-структура-проекта)
- [Установка](#-установка)
- [Редактирование контента](#-редактирование-контента)
- [SEO](#-seo)
- [Контакты](#-контакты)

---

## 🚀 Технологии

| Технология | Версия | Назначение |
|------------|--------|------------|
| React | 18.3 | UI-фреймворк |
| TypeScript | 5.x | Типизация |
| Vite | 5.x | Сборка |
| Tailwind CSS | 3.x | Стилизация |
| React Router | 6.x | Маршрутизация |
| Lucide React | 0.462 | Иконки |

---

## 📁 Структура проекта

```
stekloprom/
├── public/
│   ├── favicon.ico          # Иконка сайта
│   ├── robots.txt           # Инструкции для поисковых роботов
│   └── sitemap.xml          # Карта сайта для SEO
│
├── src/
│   ├── assets/images/       # Изображения сайта
│   ├── components/
│   │   ├── layout/          # Header, Footer, Layout, Breadcrumbs
│   │   ├── sections/        # Секции страниц (Hero, WhyUs, и т.д.)
│   │   └── ui/              # UI-компоненты (Modal, Button, и т.д.)
│   ├── pages/               # Страницы сайта
│   ├── hooks/               # React-хуки (useSeoMeta, useModal)
│   ├── utils/               # Утилиты (seo.ts, validation.ts)
│   ├── index.css            # Глобальные стили
│   └── App.tsx              # Главный компонент
│
├── index.html               # HTML-шаблон
├── vite.config.ts           # Конфигурация Vite
└── tailwind.config.ts       # Конфигурация Tailwind
```

---

## 💻 Установка

### Требования
- Node.js 18+ или Bun

### Установка и запуск

```bash
# Установка зависимостей
npm install

# Запуск в режиме разработки
npm run dev

# Сборка для production
npm run build
```

Сайт будет доступен: `http://localhost:5173`

---

## ✏️ Редактирование контента

### Контактные данные
- **Главный файл:** `src/utils/seo.ts` → `COMPANY_DATA`
- **Футер:** `src/components/layout/Footer.tsx` → `CONTACT_INFO`
- **Контакты:** `src/pages/Contacts.tsx` → `CONTACT_INFO`

### Главный баннер
`src/components/sections/HeroSection.tsx` → `HERO_CONTENT`

### Каталог продукции
`src/pages/Catalog.tsx` → массив `PRODUCTS`

### Блог
`src/pages/Blog.tsx` → массив `BLOG_ARTICLES`

### Портфолио
- Главная: `src/components/sections/CasesGallery.tsx`
- Полный список: `src/pages/Cases.tsx`

---

## 🎨 Фирменные цвета

| Цвет | HEX | Использование |
|------|-----|---------------|
| Синий | `#00a3d5` | Логотип, заголовки |
| Темно-синий | `#00407e` | Основной текст |
| Красный | `#ff342f` | Кнопки CTA |
| Белый | `#fefefe` | Фон |

CSS-переменные в `src/index.css`

---

## 🔍 SEO

- **Мета-теги:** хук `useSeoMeta` в каждой странице
- **Robots.txt:** `public/robots.txt`
- **Sitemap:** `public/sitemap.xml`
- **JSON-LD:** `src/utils/seo.ts`

Подробнее: см. файл `SEO-AUDIT-REPORT.md`

---

## 📱 Адаптивность

- Мобильные: 320-767px
- Планшеты: 768-1199px
- Десктоп: 1200px+

---

## 📞 Контакты компании

**Стеклопром**  
📞 +7 (863) 123-45-67  
✉️ info@stekloprom-rostov.ru  
📍 г. Ростов-на-Дону, ул. Промышленная, 15

---

## 📄 Лицензия

© 2024 Стеклопром. Все права защищены.

---

## 📚 Документация

- `README.md` — этот файл
- `SEO-AUDIT-REPORT.md` — отчёт SEO-аудита
- `CONTENT-MANAGER-GUIDE.md` — инструкция для контент-менеджера
