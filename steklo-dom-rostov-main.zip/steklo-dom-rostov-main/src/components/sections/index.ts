/**
 * Экспорт секций
 */

export { default as HeroSection } from './HeroSection';
export { default as PopularSolutions } from './PopularSolutions';
export { default as WhyUs } from './WhyUs';
export { default as HowWeWork } from './HowWeWork';
export { default as ForWhom } from './ForWhom';
export { default as CasesGallery } from './CasesGallery';
export { default as ContactForm } from './ContactForm';
export { default as CallToAction } from './CallToAction';
